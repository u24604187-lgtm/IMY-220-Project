import { MongoClient } from "mongodb";

let client;
let db;

async function connectDB() {
    const uri = process.env.MONGO_URI;
    client = new MongoClient(uri);
    await client.connect();
    
    db = client.db("photoshare")

    console.log("Connected to MongoDB")
}

function getDB() {
    if(!db){
        throw new Error("Database not connected");
    }
      
    return db;
}

export { connectDB, getDB };