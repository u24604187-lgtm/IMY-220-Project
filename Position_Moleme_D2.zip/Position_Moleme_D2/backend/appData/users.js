import { ObjectId } from "mongodb";
import { getDB } from "../db.js";

const users = () => getDB().collection("users");
const id = (value) => new ObjectId(value);

export const publicUser = ({ password, ...rest }) => rest;
export const findByEmail = (email) => users().findOne({ email });
export const findById = (userId) => users().findOne({ _id: id(userId) });
export const getAllUsers = () => users().find().toArray();

export async function createUser({ username, email, password }) {
    const user = {
        username, email, password,
        role: "user",
        bio: "",
        profilePicture: "",
        friends: [],
        friendRequests: [], 
        createdAt: new Date(),
    };
    
    const result = await users().insertOne(user);

    return { _id: result.insertedId, ...user };
}

export function findDuplicate(userId, { username, email }) {
    const conditions = [];
    if (username) conditions.push({ username });
    if (email) conditions.push({ email });
    if (!conditions.length) return null;
    return users().findOne({ _id: { $ne: id(userId) }, $or: conditions });
}

export async function updateUser(userId, fields) {
    await users().updateOne({ _id: id(userId) }, { $set: fields });
    return findById(userId);
}


export async function deleteUser(userId) {
    const db = getDB();
    const _id = id(userId);

    const myPosts = await db.collection("posts").find({ userId: _id }).project({ _id: 1 }).toArray();
    const postIds = myPosts.map((p) => p._id);

    await db.collection("posts").deleteMany({ userId: _id });
    await db.collection("albums").updateMany({}, { $pull: { posts: { $in: postIds } } });
    await db.collection("albums").deleteMany({ userId: _id });
    await db.collection("posts").updateMany({}, { $pull: { comments: { userId: _id }, reports: { userId: _id } } });
    await db.collection("activity").deleteMany({ $or: [{ userId: _id }, { refId: { $in: postIds } }] });
    await users().updateMany({}, { $pull: { friends: _id, friendRequests: _id } });
    await users().deleteOne({ _id });
}

// ---------- Friends ----------
export const sendRequest = (fromId, toId) =>
    users().updateOne({ _id: id(toId) }, { $addToSet: { friendRequests: id(fromId) } });

export async function acceptRequest(meId, fromId) {
    await users().updateOne(
        { _id: id(meId) },
        { $pull: { friendRequests: id(fromId) }, $addToSet: { friends: id(fromId) } }
    );
    await users().updateOne({ _id: id(fromId) }, { $addToSet: { friends: id(meId) } });
}

export const declineRequest = (meId, fromId) =>
    users().updateOne({ _id: id(meId) }, { $pull: { friendRequests: id(fromId) } });

export async function unfriend(meId, otherId) {
    await users().updateOne({ _id: id(meId) }, { $pull: { friends: id(otherId) } });
    await users().updateOne({ _id: id(otherId) }, { $pull: { friends: id(meId) } });
}

export const getUsersByIds = (ids) => users().find({ _id: { $in: ids } }).toArray();