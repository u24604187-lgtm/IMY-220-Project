// Related Posts put together, board
import { ObjectId } from "mongodb";
import { getDB } from "../db.js";

const albums = () => getDB().collection("albums");
const id = (value) => new ObjectId(value);

export const getAlbums = (userId) =>
    albums().find(userId ? { userId: id(userId) } : {}).sort({ createdAt: -1 }).toArray();

export const getAlbum = (albumId) => albums().findOne({ _id: id(albumId) });

export async function getAlbumWithPosts(albumId) {
    const album = await getAlbum(albumId);
    if (!album) return null;
    const posts = await getDB()
        .collection("posts")
        .find({ _id: { $in: album.posts } })
        .sort({ createdAt: -1 })
        .toArray();
    return { ...album, posts };
}

export async function createAlbum({ userId, username, name }) {
    const album = {
        userId: id(userId),
        username,
        name,
        posts: [],
        createdAt: new Date(),
    };
    const result = await albums().insertOne(album);
    return { _id: result.insertedId, ...album };
}

export async function editAlbum(albumId, { name }) {
    await albums().updateOne({ _id: id(albumId) }, { $set: { name } });
    return getAlbum(albumId);
}


export async function deleteAlbum(albumId) {
    await albums().deleteOne({ _id: id(albumId) });
    await getDB().collection("activity").deleteMany({ refId: id(albumId) });
}

export const addPostToAlbum = (albumId, postId) =>
    albums().updateOne({ _id: id(albumId) }, { $addToSet: { posts: id(postId) } });

export const removePostFromAlbum = (albumId, postId) =>
    albums().updateOne({ _id: id(albumId) }, { $pull: { posts: id(postId) } });

