//local - friends feed
//global - all feeds

import { ObjectId } from "mongodb";
import { getDB } from "../db.js";

const activity = () => getDB().collection("activity");
const id = (value) => new ObjectId(value);

export const logActivity = ({ userId, username, type, text, refId }) =>
    activity().insertOne({
        userId: id(userId),
        username,
        type,                              
        text,                              
        refId: refId ? id(refId) : null,   
        createdAt: new Date(),
    });


export function getFeed(scope, user) {
    const filter = scope === "local"
        ? { type: "post", userId: { $in: user.friends } }
        : {};

    return activity().aggregate([
        { $match: filter },
        { $sort: { createdAt: -1 } },
        { $limit: 50 },
  
        { $lookup: { from: "posts", localField: "refId", foreignField: "_id", as: "post" } },
        { $lookup: { from: "albums", localField: "refId", foreignField: "_id", as: "album" } },
        { $addFields: {
            post: { $first: "$post" },
            album: { $first: "$album" },
        } },
    ]).toArray();
}