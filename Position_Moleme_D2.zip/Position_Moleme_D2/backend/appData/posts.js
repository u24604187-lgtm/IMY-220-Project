import { ObjectId } from "mongodb";
import { getDB } from "../db.js";

const posts = () => getDB().collection("posts");
const id = (value) => new ObjectId(value);

export const getPosts = (userId) =>
    posts().find(userId ? { userId: id(userId) } : {}).sort({ createdAt: -1 }).toArray();

export const getPost = (postId) => posts().findOne({ _id: id(postId) });

export async function createPost({ userId, username, image, caption }) {
    const post = {
        userId: id(userId),
        username,
        image,
        caption,
        comments: [],
        reports: [],
        createdAt: new Date(),
    };
    const result = await posts().insertOne(post);
    return { _id: result.insertedId, ...post };
}

export async function editPost(postId, { caption }) {
    await posts().updateOne({ _id: id(postId) }, { $set: { caption } });
    return getPost(postId);
}

export async function deletePost(postId) {
    const db = getDB();
    await posts().deleteOne({ _id: id(postId) });
    await db.collection("albums").updateMany({}, { $pull: { posts: id(postId) } });
    await db.collection("activity").deleteMany({ refId: id(postId) });
}

export async function addComment(postId, { userId, username, text }) {
    const comment = { _id: new ObjectId(), userId: id(userId), username, text, createdAt: new Date() };
    await posts().updateOne({ _id: id(postId) }, { $push: { comments: comment } });
    return comment;
}

export const addReport = (postId, { userId, reason }) =>
    posts().updateOne(
        { _id: id(postId) },
        { $push: { reports: { userId: id(userId), reason, createdAt: new Date() } } }
    );

export const getReportReasons = () => getDB().collection("reportReasons").find().toArray();

export async function ensureReportReasons() {
    const reasons = getDB().collection("reportReasons");

    if(await reasons.countDocuments() === 0){
        await reasons.insertMany([
            { reason: "Hate speech" },
            { reason: "Inappropriate content" },
            { reason: "Violence" },
            { reason: "Misinformation" },
            { reason: "Copyright infringement" },
            { reason: "Child endangerment" },
        ]);
    }
}