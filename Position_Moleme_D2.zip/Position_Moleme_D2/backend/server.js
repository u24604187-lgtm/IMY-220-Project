import "dotenv/config";
import express from "express";
import cors from "cors";

import { connectDB, getDB } from "./db.js";
import * as Users from "./appData/users.js";
import * as Posts from "./appData/posts.js";
import * as Albums from "./appData/albums.js";
import * as Activity from "./appData/Activity.js";

const app = express();
const PORT = 5000;

app.use(cors()); 
app.use(express.json()); 

//.........................................................
//------------------D01------------------------------------
//.........................................................

//authentifucation

async function requireUser(req, res, next) {
    const userId = req.headers["x-user-id"];
    if(!userId){
        return res.status(401).json({ error: "Not logged in" });
    }

    const user = await Users.findById(userId);

    if(!user){ 
        return res.status(401).json({ error: "User not found" });
    }

    req.user = user;
    next();
}

const isOwner = (doc, user) => doc.userId.toString() === user._id.toString();

app.post("/api/signup", async (req, res) => {
    const { username, email, password } = req.body;

    if(!username || !email || !password){
        return res.status(400).json({ error: "Username, email and password are required" });
    }

    const exists = await getDB().collection("users").findOne({ $or: [{ email }, { username }] });
    if(exists){
        return res.status(409).json({ error: "Username or email already in use" });
    }

    const user = await Users.createUser({ username, email, password });
    res.status(201).json({
        success: true,
        message: "Profile created successfully. Welcome to DePict",
        user: Users.publicUser(user),
    });
});

app.post("/api/signin", async (req, res) => {
    const { email, password } = req.body;

    if(!email || !password){
        return res.status(400).json({ error: "Email and password are required" });
    }

    const user = await Users.findByEmail(email);
    if(!user || user.password !== password){
        return res.status(401).json({ error: "Incorrect email or password" });
    }

    res.json({
        success: true,
        message: `User ${user.username} is signed in`,
        user: Users.publicUser(user),
    });
});

app.post("/api/logout", (req, res) => res.json({ success: true }));


//------------------Profiles-------------------------------

app.get("/api/me", requireUser, (req, res) => {
    res.json(Users.publicUser(req.user));
});

app.get("/api/users", requireUser, async (req, res) => {
    const all = await Users.getAllUsers();
    res.json(all.map(({ password, friendRequests, ...rest }) => rest));
});

app.get("/api/users/:id", requireUser, async (req, res) => {
    const user = await Users.findById(req.params.id);
    if(!user){
        return res.status(404).json({ error: "User not found" });
    }

    const { password, friendRequests, ...safe } = user;
    const isMe = user._id.toString() === req.user._id.toString();
    res.json(isMe ? Users.publicUser(user) : safe);
});

app.put("/api/users/:id", requireUser, async (req, res) => {
    if(req.params.id !== req.user._id.toString()){
        return res.status(403).json({ error: "You can only edit your own profile" });
    }

    const { username, email, bio, profilePicture } = req.body;
    const fields = {};
    if(username){
        fields.username = username;
    }
    if(email){
        fields.email = email;
    }
    if(bio !== undefined){
        fields.bio = bio;
    }
    if(profilePicture !== undefined){
        fields.profilePicture = profilePicture;
    }

    if(!Object.keys(fields).length){
        return res.status(400).json({ error: "Nothing to update" });
    }

    if(await Users.findDuplicate(req.params.id, fields)){
        return res.status(409).json({ error: "Username or email already in use" });
    }

    const updated = await Users.updateUser(req.params.id, fields);
    res.json(Users.publicUser(updated));
});

app.delete("/api/users/:id", requireUser, async (req, res) => {
    if(req.params.id !== req.user._id.toString()){
        return res.status(403).json({ error: "You can only delete your own profile" });
    }

    await Users.deleteUser(req.params.id);
    res.json({ success: true });
});


//------------------Friends--------------------------------

app.get("/api/users/:id/friends", requireUser, async (req, res) => {
    const user = await Users.findById(req.params.id);
    if(!user){
        return res.status(404).json({ error: "User not found" });
    }

    const friends = await Users.getUsersByIds(user.friends);
    res.json(friends.map(Users.publicUser));
});

app.get("/api/friend-requests", requireUser, async (req, res) => {
    const senders = await Users.getUsersByIds(req.user.friendRequests);
    res.json(senders.map(Users.publicUser));
});

app.post("/api/users/:id/friend-request", requireUser, async (req, res) => {
    const target = await Users.findById(req.params.id);
    if(!target){
        return res.status(404).json({ error: "User not found" });
    }

    if(target._id.toString() === req.user._id.toString()){
        return res.status(400).json({ error: "You cannot friend yourself" });
    }

    if(req.user.friends.some((f) => f.toString() === req.params.id)){
        return res.status(400).json({ error: "Already friends" });
    }

    if(req.user.friendRequests.some((f) => f.toString() === req.params.id)){
        return res.status(400).json({ error: "They already sent you a request, accept it instead" });
    }

    await Users.sendRequest(req.user._id, req.params.id);
    res.json({ success: true });
});

app.post("/api/users/:id/accept", requireUser, async (req, res) => {
    if(!req.user.friendRequests.some((f) => f.toString() === req.params.id)){
        return res.status(400).json({ error: "No request from this user" });
    }

    const friend = await Users.findById(req.params.id);
    if(!friend){
        return res.status(404).json({ error: "User not found" });
    }

    await Users.acceptRequest(req.user._id, req.params.id);
    await Activity.logActivity({
        userId: req.user._id,
        username: req.user.username,
        type: "friend",
        text: `became friends with ${friend.username}`,
        refId: friend._id,
    });
    res.json({ success: true });
});

app.post("/api/users/:id/decline", requireUser, async (req, res) => {
    await Users.declineRequest(req.user._id, req.params.id);
    res.json({ success: true });
});

app.delete("/api/users/:id/friend", requireUser, async (req, res) => {
    await Users.unfriend(req.user._id, req.params.id);
    res.json({ success: true });
});


//------------------Posts---------------------------

app.get("/api/posts", requireUser, async (req, res) => {
    res.json(await Posts.getPosts(req.query.userId));
});

app.get("/api/posts/:id", requireUser, async (req, res) => {
    const post = await Posts.getPost(req.params.id);
    if(!post){
        return res.status(404).json({ error: "Post not found" });
    }

    res.json(post);
});

app.post("/api/posts", requireUser, async (req, res) => {
    const { image, caption } = req.body;

    if(!image || !caption){
        return res.status(400).json({ error: "Image and caption are required" });
    }

    const post = await Posts.createPost({
        userId: req.user._id,
        username: req.user.username,
        image,
        caption,
    });

    await Activity.logActivity({
        userId: req.user._id,
        username: req.user.username,
        type: "post",
        text: "created a new post",
        refId: post._id,
    });

    res.status(201).json(post);
});

app.put("/api/posts/:id", requireUser, async (req, res) => {
    const post = await Posts.getPost(req.params.id);
    if(!post){
        return res.status(404).json({ error: "Post not found" });
    }

    if(!isOwner(post, req.user)){
        return res.status(403).json({ error: "Not your post" });
    }

    const { caption } = req.body;
    if(!caption){
        return res.status(400).json({ error: "Caption is required" });
    }

    res.json(await Posts.editPost(req.params.id, { caption }));
});

app.delete("/api/posts/:id", requireUser, async (req, res) => {
    const post = await Posts.getPost(req.params.id);
    if(!post){
        return res.status(404).json({ error: "Post not found" });
    }

    if(!isOwner(post, req.user)){
        return res.status(403).json({ error: "Not your post" });
    }

    await Posts.deletePost(req.params.id);
    res.json({ success: true });
});

app.post("/api/posts/:id/comments", requireUser, async (req, res) => {
    const post = await Posts.getPost(req.params.id);
    if(!post){
        return res.status(404).json({ error: "Post not found" });
    }

    const { text } = req.body;
    if(!text){
        return res.status(400).json({ error: "Comment cannot be empty" });
    }

    const comment = await Posts.addComment(req.params.id, {
        userId: req.user._id,
        username: req.user.username,
        text,
    });

    await Activity.logActivity({
        userId: req.user._id,
        username: req.user.username,
        type: "comment",
        text: `commented on ${post.username}'s post`,
        refId: post._id,
    });

    res.status(201).json(comment);
});

//------------------ reasons --------------------------
app.get("/api/report-reasons", requireUser, async (req, res) => {
    res.json(await Posts.getReportReasons());
});

app.post("/api/posts/:id/report", requireUser, async (req, res) => {
    const post = await Posts.getPost(req.params.id);
    if(!post){
        return res.status(404).json({ error: "Post not found" });
    }

    const { reason } = req.body;
    if(!reason){
        return res.status(400).json({ error: "A reason is required" });
    }


    const allowed = await Posts.getReportReasons();
    if(!allowed.some((rea) => rea.reason === reason)){
        return res.status(400).json({ error: "Invalid report reason" });
    }

    await Posts.addReport(req.params.id, { userId: req.user._id, reason });
    res.json({ success: true });
});


//------------------Albums---------------------------------

app.get("/api/albums", requireUser, async (req, res) => {
    res.json(await Albums.getAlbums(req.query.userId));
});

app.get("/api/albums/:id", requireUser, async (req, res) => {
    const album = await Albums.getAlbumWithPosts(req.params.id);
    if(!album){
        return res.status(404).json({ error: "Album not found" });
    }

    res.json(album);
});

app.post("/api/albums", requireUser, async (req, res) => {
    
    const { name } = req.body;

    if(!name){
        return res.status(400).json({ error: "Album name is required" });
    }

    const album = await Albums.createAlbum({
        userId: req.user._id,
        username: req.user.username,
        name,
    });

    await Activity.logActivity({
        userId: req.user._id,
        username: req.user.username,
        type: "album",
        text: `created the album "${album.name}"`,
        refId: album._id,
    });

    res.status(201).json(album);
});

app.put("/api/albums/:id", requireUser, async (req, res) => {
    const album = await Albums.getAlbum(req.params.id);
    if(!album){
        return res.status(404).json({ error: "Album not found" });
    }

    if(!isOwner(album, req.user)){
        return res.status(403).json({ error: "Not your album" });
    }

    // PUT /api/albums/:id
const { name } = req.body;
if(!name){
    return res.status(400).json({ error: "Album name is required" });
}

res.json(await Albums.editAlbum(req.params.id, { name }));

});

app.delete("/api/albums/:id", requireUser, async (req, res) => {
    const album = await Albums.getAlbum(req.params.id);
    if(!album){
        return res.status(404).json({ error: "Album not found" });
    }

    if(!isOwner(album, req.user)){
        return res.status(403).json({ error: "Not your album" });
    }

    await Albums.deleteAlbum(req.params.id);
    res.json({ success: true });
});

// Save a post to an album
app.post("/api/albums/:id/posts/:postId", requireUser, async (req, res) => {
    const album = await Albums.getAlbum(req.params.id);
    if(!album){
        return res.status(404).json({ error: "Album not found" });
    }

    if(!isOwner(album, req.user)){
        return res.status(403).json({ error: "Not your album" });
    }

    const post = await Posts.getPost(req.params.postId);
    if(!post){
        return res.status(404).json({ error: "Post not found" });
    }

    await Albums.addPostToAlbum(req.params.id, req.params.postId);
    res.json(await Albums.getAlbumWithPosts(req.params.id));
});

// Remove a post from an album
app.delete("/api/albums/:id/posts/:postId", requireUser, async (req, res) => {
    const album = await Albums.getAlbum(req.params.id);
    if(!album){
        return res.status(404).json({ error: "Album not found" });
    }

    if(!isOwner(album, req.user)){
        return res.status(403).json({ error: "Not your album" });
    }

    await Albums.removePostFromAlbum(req.params.id, req.params.postId);
    res.json(await Albums.getAlbumWithPosts(req.params.id));
});


//------------------Activity feed--------------------

app.get("/api/activity", requireUser, async (req, res) => {
    const scope = req.query.scope === "local" ? "local" : "global";
    res.json(await Activity.getFeed(scope, req.user));
});





//--------------Error handling--------------------


app.use((err, req, res, next) => {
    console.error(err);
    if(err.name === "BSONError" || err.name === "BSONTypeError"){
        return res.status(400).json({ error: "Invalid id" });
    }
    res.status(500).json({ error: "Something went wrong" });
});

connectDB()
    .then(async () => {
        await Posts.ensureReportReasons();
        app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
    })
    .catch((error) => console.error("Failed to start server:", error));