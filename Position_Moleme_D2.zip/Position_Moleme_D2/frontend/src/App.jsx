import {
    BrowserRouter,
    Routes,
    Route,
    Navigate
} from "react-router-dom";

import Home from "./pages/Home";
import Splash from "./pages/Splash";
import Profile from "./pages/Profile";
import Navigation from "./components/Navigation";
import NotFound from "./pages/NotFound";
import Post from "./pages/Post";
import Search from "./pages/Search";

function ProtectedRoute({ children }) {
    const user = localStorage.getItem("user");

    if (!user) {
        return <Navigate to="/" replace />;
    }

    return children;
}

function App() {
  return (
    <BrowserRouter>
      <Navigation />

      <Routes>
          <Route path="/" element={<Splash />} />
          <Route path="/home" element={<ProtectedRoute><Home /></ProtectedRoute>} />
          <Route path="/post/:id" element={<ProtectedRoute><Post /></ProtectedRoute>} />
          <Route path="/profile/:id" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
          <Route path="/search" element={<ProtectedRoute><Search /></ProtectedRoute>} />
          <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;