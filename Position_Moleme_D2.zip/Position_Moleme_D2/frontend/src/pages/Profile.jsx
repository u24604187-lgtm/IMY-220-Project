import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import PostPreview from "../components/PostPreview";
import FriendList from "../components/Friendlist";
import CreatePost from "../components/CreatePost";
import Albums from "../components/Album";

const API = "http://localhost:5000/api";

function Profile() {
    const { id } = useParams();
    const navigate = useNavigate();
    const stored = JSON.parse(localStorage.getItem("user"));
    const headers = { "Content-Type": "application/json", "x-user-id": stored._id };
    const isMe = id === stored._id;

    const [profile, setProfile] = useState(null);
    const [me, setMe] = useState(null);
    const [posts, setPosts] = useState([]);
    const [friends, setFriends] = useState([]);
    const [requests, setRequests] = useState([]);
    const [editing, setEditing] = useState(false);
    const [username, setUsername] = useState("");
    const [bio, setBio] = useState("");
    const [pfp, setPfp] = useState("");
    const [requested, setRequested] = useState(false);
    const [error, setError] = useState("");
    const [message, setMessage] = useState("");

    async function loadAll(){
        try{
            const [profileRes, meRes, postsRes, friendsRes] = await Promise.all([
                fetch(`${API}/users/${id}`, { headers }),
                fetch(`${API}/me`, { headers }),
                fetch(`${API}/posts?userId=${id}`, { headers }),
                fetch(`${API}/users/${id}/friends`, { headers }),
            ]);

            if(!profileRes.ok){
                setError("Profile not found");
                return;
            }

            setProfile(await profileRes.json());
            setMe(await meRes.json());
            setPosts(await postsRes.json());
            setFriends(await friendsRes.json());
            setError("");

            if(isMe){
                const requestsRes = await fetch(`${API}/friend-requests`, { headers });
                if(requestsRes.ok){
                    setRequests(await requestsRes.json());
                }
            }
        }catch(err){
            setError("Could not load the profile");
        }
    }

    useEffect(() => {
        setRequested(false);
        setEditing(false);
        setMessage("");
        loadAll();
    }, [id]);

    function startEditing(){
        setUsername(profile.username);
        setBio(profile.bio);
        setPfp(profile.profilePicture);
        setEditing(true);
    }

    function handlePfpChange(e){
        const selected = e.target.files[0];

        if(!selected){
            return;
        }

        const reader = new FileReader();
        reader.onloadend = () => {
            setPfp(reader.result);
        };
        reader.readAsDataURL(selected);
    }

    async function saveProfile(){
        if(username === ""){
            setMessage("Username is required");
            return;
        }

        const response = await fetch(`${API}/users/${id}`, {
            method: "PUT",
            headers,
            body: JSON.stringify({ username, bio, profilePicture: pfp }),
        });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        localStorage.setItem("user", JSON.stringify(data));
        setEditing(false);
        setMessage("");
        loadAll();
    }

    async function deleteProfile(){
        if(!window.confirm("Delete your profile? This cannot be undone.")){
            return;
        }

        const response = await fetch(`${API}/users/${id}`, { method: "DELETE", headers });

        if(!response.ok){
            const data = await response.json();
            setMessage(data.error);
            return;
        }

        localStorage.removeItem("user");
        navigate("/");
    }

    async function sendRequest(){
        const response = await fetch(`${API}/users/${id}/friend-request`, { method: "POST", headers });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        setRequested(true);
        setMessage("");
    }

    async function unfriend(){
        await fetch(`${API}/users/${id}/friend`, { method: "DELETE", headers });
        loadAll();
    }

    async function answerRequest(fromId, action){
        await fetch(`${API}/users/${fromId}/${action}`, { method: "POST", headers });
        loadAll();
    }

    if(error){
        return <p style={{ color: "red" }}>{error}</p>;
    }

    if(!profile || !me){
        return <p>Loading...</p>;
    }

    const isFriend = me.friends.includes(id);
    const theySentRequest = me.friendRequests.includes(id);

    return(
        <div className="profile-page">
            {profile.profilePicture && <img src={profile.profilePicture} alt={profile.username} width="150" />}
            <h1>{profile.username}</h1>
            <p>{profile.bio}</p>
            <span>{friends.length} friends</span>

            {message && <p style={{ color: "red" }}>{message}</p>}

            {isMe && !editing && (
                <div>
                    <button onClick={startEditing}>Edit profile</button>
                    <button onClick={deleteProfile}>Delete profile</button>
                </div>
            )}

            {isMe && editing && (
                <div>
                    <input value={username} placeholder="Username" onChange={(e) => setUsername(e.target.value)} />
                    <textarea value={bio} placeholder="Bio" onChange={(e) => setBio(e.target.value)} />
                    <input type="file" accept="image/*" onChange={handlePfpChange} />
                    {pfp && <img src={pfp} alt="preview" width="80" />}
                    <button onClick={saveProfile}>Save</button>
                    <button onClick={() => setEditing(false)}>Cancel</button>
                </div>
            )}

            {!isMe && (
                <div>
                    {isFriend && <button onClick={unfriend}>Unfriend</button>}
                    {!isFriend && theySentRequest && (
                        <div>
                            <button onClick={() => answerRequest(id, "accept")}>Accept request</button>
                            <button onClick={() => answerRequest(id, "decline")}>Decline</button>
                        </div>
                    )}
                    {!isFriend && !theySentRequest && !requested && (
                        <button onClick={sendRequest}>Add friend</button>
                    )}
                    {!isFriend && !theySentRequest && requested && <p>Request sent</p>}
                </div>
            )}

            {isMe && requests.length > 0 && (
                <div>
                    <h2>Friend requests</h2>
                    {requests.map((r) => (
                        <div key={r._id}>
                            <span>{r.username}</span>
                            <button onClick={() => answerRequest(r._id, "accept")}>Accept</button>
                            <button onClick={() => answerRequest(r._id, "decline")}>Decline</button>
                        </div>
                    ))}
                </div>
            )}

            <h1>Posts</h1>
            <div>
                {posts.map((post) => (
                    <PostPreview key={post._id} post={post} />
                ))}
            </div>

            <h2>Friends</h2>
            <FriendList friends={friends} />

            <Albums userId={id} isMe={isMe} />

            {isMe && (
                <div>
                    <h2>Create a Post</h2>
                    <CreatePost onCreated={loadAll} />
                </div>
            )}
        </div>
    );
}

export default Profile;