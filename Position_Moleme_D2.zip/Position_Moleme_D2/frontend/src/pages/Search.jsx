import { useEffect, useState } from "react";
import SearchBar from "../components/SearchBar";
import ProfilePreview from "../components/ProfilePreview";

function Search() {
    const user = JSON.parse(localStorage.getItem("user"));
    const [searchTerm, setSearchTerm] = useState("");
    const [profiles, setProfiles] = useState([]);
    const [error, setError] = useState("");

    useEffect(() => {
        async function loadUsers(){
            try{
                const response = await fetch("http://localhost:5000/api/users", {
                    headers: { "x-user-id": user._id },
                });
                const data = await response.json();

                if(!response.ok){
                    setError(data.error);
                    return;
                }

                setProfiles(data);
            }catch(err){
                setError("Could not load users");
            }
        }

        loadUsers();
    }, []);

    const filteredProfiles = profiles.filter((profile) =>
        profile.username.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="search-page">
            <h1>Search Profiles</h1>
            <SearchBar search={searchTerm} onSearchChange={setSearchTerm} />
            {error && <p style={{ color: "red" }}>{error}</p>}

            <div className="search-results">
                {filteredProfiles.map((profile) => (
                    <ProfilePreview key={profile._id} {...profile} />
                ))}
            </div>
        </div>
    );
}

export default Search;