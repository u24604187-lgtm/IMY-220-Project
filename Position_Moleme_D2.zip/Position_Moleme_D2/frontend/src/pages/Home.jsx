import { useEffect, useState } from "react";
import Feed from "../components/Feed";

function Home() {
    const user = JSON.parse(localStorage.getItem("user"));
    const [scope, setScope] = useState("global");
    const [items, setItems] = useState([]);
    const [error, setError] = useState("");

    useEffect(() => {
        async function loadFeed(){
            try{
                const response = await fetch(`http://localhost:5000/api/activity?scope=${scope}`, {
                    headers: { "x-user-id": user._id },
                });
                const data = await response.json();

                if(!response.ok){
                    setError(data.error);
                    return;
                }

                setError("");
                setItems(data);
            }catch(err){
                setError("Could not load the feed");
            }
        }

        loadFeed();
    }, [scope]);

    return(
        <div className="home">
            <h1>Depict</h1>

            <button onClick={() => setScope("global")}>Global feed</button>
            <button onClick={() => setScope("local")}>Friends' posts</button>
            <h2>{scope === "global" ? "Global feed" : "Friends' posts"}</h2>

            {error && <p style={{ color: "red" }}>{error}</p>}
            <Feed items={items} />
        </div>
    );
}

export default Home;
