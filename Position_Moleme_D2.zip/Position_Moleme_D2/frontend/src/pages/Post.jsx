import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import Image from "../components/Image";
import Comments from "../components/Comments";

const API = "http://localhost:5000/api";

function Post() {
    const { id } = useParams();
    const navigate = useNavigate();
    const user = JSON.parse(localStorage.getItem("user"));
    const headers = { "Content-Type": "application/json", "x-user-id": user._id };

    const [post, setPost] = useState(null);
    const [error, setError] = useState("");
    const [message, setMessage] = useState("");
    const [editing, setEditing] = useState(false);
    const [caption, setCaption] = useState("");
    const [reasons, setReasons] = useState([]);
    const [reason, setReason] = useState("");
    const [albums, setAlbums] = useState([]);
    const [albumId, setAlbumId] = useState("");

    async function loadPost(){
        try{
            const response = await fetch(`${API}/posts/${id}`, { headers });
            const data = await response.json();

            if(!response.ok){
                setError(data.error);
                return;
            }

            setPost(data);
            setCaption(data.caption);
        }catch(err){
            setError("Could not load the post");
        }
    }

    async function loadAlbums(){
        try{
            const albumsRes = await fetch(`${API}/albums?userId=${user._id}`, { headers });

            if(albumsRes.ok){
                setAlbums(await albumsRes.json());
            }
        }catch(err){
            console.error(err);
        }
    }

    async function loadReason(){
        try{
            const reasonsRes = await fetch(`${API}/report-reasons`, { headers });

            if(reasonsRes.ok){
                setReasons(await reasonsRes.json());
            }
        }catch(err){
            console.error(err);
        }
    }

    useEffect(() => {
        loadPost();
        loadAlbums();
        loadReason();
    }, [id]);

    async function saveCaption(){
        if(caption === ""){
            setMessage("Caption is required");
            return;
        }

        const response = await fetch(`${API}/posts/${id}`, {
            method: "PUT",
            headers,
            body: JSON.stringify({ caption }),
        });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        setPost(data);
        setEditing(false);
        setMessage("");
    }

    async function deletePost(){
        const response = await fetch(`${API}/posts/${id}`, { method: "DELETE", headers });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        navigate(`/profile/${user._id}`);
    }

    async function reportPost(){
        if(reason === ""){
            setMessage("Select the reason for your report");
            return;
        }

        const response = await fetch(`${API}/posts/${id}/report`, {
            method: "POST",
            headers,
            body: JSON.stringify({ reason }),
        });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        setReason("");
        setMessage("Post reported");
    }

    async function saveToAlbum(){
        if(albumId === ""){
            setMessage("Pick the album you wish to save this post on");
            return;
        }

        const response = await fetch(`${API}/albums/${albumId}/posts/${id}`, {
            method: "POST",
            headers,
        });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        setMessage("Saved to album");
    }

    if(error){
        return <p style={{ color: "red" }}>{error}</p>;
    }

    if(!post){
        return <p>Loading...</p>;
    }

    const isOwner = post.userId === user._id;

    return (
        <div>
            <h1><Link to={`/profile/${post.userId}`}>{post.username}</Link></h1>
            <Image src={post.image} alt={post.caption}/>

            {editing ? (
                <div>
                    <textarea value={caption} onChange={(e) => setCaption(e.target.value)} />
                    <button onClick={saveCaption}>Save</button>
                    <button onClick={() => setEditing(false)}>Cancel</button>
                </div>
            ) : (
                <p>{post.caption}</p>
            )}

            {isOwner && !editing && (
                <div>
                    <button onClick={() => setEditing(true)}>Edit caption</button>
                    <button onClick={deletePost}>Delete post</button>
                </div>
            )}

            <div>
                <select value={albumId} onChange={(e) => setAlbumId(e.target.value)}>
                    <option value="">Save to album...</option>
                    {albums.map((album) => (
                        <option key={album._id} value={album._id}>{album.name}</option>
                    ))}
                </select>
                <button onClick={saveToAlbum}>Save</button>
            </div>

            <div className="report">
                <h3>Report this post</h3>
                {reasons.map((r) => (
                    <label key={r._id}>
                        <input
                            type="radio"
                            name="reason"
                            value={r.reason}
                            checked={reason === r.reason}
                            onChange={(e) => setReason(e.target.value)}
                        />
                        {r.reason}
                    </label>
                ))}
                <button onClick={reportPost}>Report</button>
            </div>

            {message && <p>{message}</p>}

            <Comments comments={post.comments} postId={id} onAdded={loadPost} />
        </div>
    );
}

export default Post;