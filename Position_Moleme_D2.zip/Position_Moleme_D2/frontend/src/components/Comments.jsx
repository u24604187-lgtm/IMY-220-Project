
function Comments({ comments }){

    const user = JSON.parse(localStorage.getItem("user"));
    const [text, setText] = useState("");
    const [error, setError] = useState(""); 

    const handleSubmit = async(e) => {
        e.preventDefault();

        if(text === ""){
            setError("You have not writen a comment yet");
            return;
        }

        try{
            const response = await fetch(`http://localhost:5000/api/posts/${postId}/comments`, {
                method: "POST",
                headers: { "Content-Type": "application/json", "x-user-id": user._id },
                body: JSON.stringify({ text }),
            });
            
            const data = await response.json();

            if(!response.ok){
                setError(data.error);
                return;
            }

            setText("");
            setError("");
            onAdded();

        }catch(err){
            setError("Could not add comment");
        }
    };


    return(
        <div className="comments">
            <h3>Comments</h3>

            {comments.map((comment) => (
                <div key={comment.id} className="comment">
                <strong>{comment.username}</strong>
                <p>{comment.text}</p>
                </div>
            ))}

            <form onSubmit={handleSubmit}>
                <input value={text} placeholder="Add a comment..." onChange={(e) => setText(e.target.value)} />
                <button type="submit">Comment</button>
            </form>
            {error && <p style={{ color: "red" }}>{error}</p>}
            
        </div>
    );
}

export default Comments;