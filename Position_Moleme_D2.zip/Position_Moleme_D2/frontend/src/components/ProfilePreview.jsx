import { useState } from "react";
import { Link } from "react-router-dom";

function ProfilePreview(props) {
    const [view, changeView] = useState(false);

    if(view == true){
        return(
            <div>
                <h1>{props.username}</h1>
                <p>{props.bio}</p>
                <h2>{props.friends.length} friends</h2>
                {props.profilePicture && <img src={props.profilePicture} alt={props.username} width="100" />}
                <Link to={`/profile/${props._id}`}>View profile</Link>
                <button onClick={() => changeView(false)}>Collapse</button>
            </div>
        );
    }else{
        return(
            <div>
                <h1>{props.username}</h1>
                <button onClick={() => changeView(true)}>Expand</button>
            </div>
        );
    }
}

export default ProfilePreview;