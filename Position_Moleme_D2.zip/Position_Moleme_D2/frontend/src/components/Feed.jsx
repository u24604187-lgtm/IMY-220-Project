import PostPreview from "./PostPreview";

function Feed({ items }){
    return(
        <div className="feed">
            {items.map((item) => (
                <div key={item._id} className="feed-item">
                    <h3><strong>{item.username}</strong> {item.text}</h3>
                    {item.post && <PostPreview post={item.post} />}
                </div>
            ))}
        </div>
    );
}

export default Feed;