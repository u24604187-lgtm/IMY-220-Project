import { Link, useNavigate } from "react-router-dom";

function Navigation() {
    const navigate = useNavigate();
    const user = JSON.parse(localStorage.getItem("user") || "null");

    if(!user){
        return null;
    }

    async function handleLogout(){
        try{
            await fetch("http://localhost:5000/api/logout", { method: "POST" });
        }catch(err){
            console.error(err);
        }
        localStorage.removeItem("user");
        navigate("/");
    }

    return (
        <nav>
            <Link to="/home">Home || </Link>
            <Link to={`/profile/${user._id}`}>Profile || </Link>
            <Link to="/search">Search || </Link>
            <button onClick={handleLogout}>Log out</button>
        </nav>
    );
}

export default Navigation;