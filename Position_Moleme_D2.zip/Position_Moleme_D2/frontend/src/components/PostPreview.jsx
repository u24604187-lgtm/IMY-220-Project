import { Link } from "react-router-dom";

function PostPreview({ post }){
    return (
        <Link to={`/post/${post.id}`} className="Post-preview">
            <h3>{post.username}</h3>
                <img src={post.postImg} alt={post.caption} />
                <p>{post.caption}</p>
                <p>{post.likeCount} likes</p>
        </Link>
    );
}

export default PostPreview