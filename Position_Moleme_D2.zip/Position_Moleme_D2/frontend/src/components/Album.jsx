import { useEffect, useState } from "react";
import PostPreview from "./PostPreview";

const API = "http://localhost:5000/api";

function Albums({ userId, isMe }){
    const user = JSON.parse(localStorage.getItem("user"));
    const headers = { "Content-Type": "application/json", "x-user-id": user._id };

    const [albums, setAlbums] = useState([]);
    const [selected, setSelected] = useState(null);
    const [name, setName] = useState("");
    const [editingId, setEditingId] = useState(null);
    const [editName, setEditName] = useState("");
    const [error, setError] = useState("");

    async function loadAlbums(){
        try{
            const response = await fetch(`${API}/albums?userId=${userId}`, { headers });

            if(response.ok){
                setAlbums(await response.json());
            }
        }catch(err){
            setError("Could not load albums");
        }
    }

    useEffect(() => {
        setSelected(null);
        loadAlbums();
    }, [userId]);

    async function openAlbum(albumId){
        const response = await fetch(`${API}/albums/${albumId}`, { headers });

        if(response.ok){
            setSelected(await response.json());
        }
    }

    async function createAlbum(e){
        e.preventDefault();

        if(name === ""){
            setError("Album name is required");
            return;
        }

        const response = await fetch(`${API}/albums`, {
            method: "POST",
            headers,
            body: JSON.stringify({ name }),
        });
        const data = await response.json();

        if(!response.ok){
            setError(data.error);
            return;
        }

        setName("");
        setError("");
        loadAlbums();
    }

    function startEdit(album){
        setEditingId(album._id);
        setEditName(album.name);
    }

    async function saveAlbum(albumId){
        if(editName === ""){
            setError("Album name is required");
            return;
        }

        const response = await fetch(`${API}/albums/${albumId}`, {
            method: "PUT",
            headers,
            body: JSON.stringify({ name: editName }),
        });
        const data = await response.json();

        if(!response.ok){
            setError(data.error);
            return;
        }

        setEditingId(null);
        setError("");
        loadAlbums();

        if(selected && selected._id === albumId){
            openAlbum(albumId);
        }
    }

    async function deleteAlbum(albumId){
        const response = await fetch(`${API}/albums/${albumId}`, { method: "DELETE", headers });

        if(!response.ok){
            const data = await response.json();
            setError(data.error);
            return;
        }

        if(selected && selected._id === albumId){
            setSelected(null);
        }
        loadAlbums();
    }

    async function removePost(postId){
        const response = await fetch(`${API}/albums/${selected._id}/posts/${postId}`, {
            method: "DELETE",
            headers,
        });

        if(response.ok){
            setSelected(await response.json());
        }
    }

    return(
        <div className="albums">
            <h2>Albums</h2>
            {error && <p style={{ color: "red" }}>{error}</p>}

            {isMe && (
                <form onSubmit={createAlbum}>
                    <input value={name} placeholder="Album name" onChange={(e) => setName(e.target.value)} />
                    <button type="submit">Create album</button>
                </form>
            )}

            {albums.map((album) => (
                <div key={album._id}>
                    {editingId === album._id ? (
                        <div>
                            <input value={editName} onChange={(e) => setEditName(e.target.value)} />
                            <button onClick={() => saveAlbum(album._id)}>Save</button>
                            <button onClick={() => setEditingId(null)}>Cancel</button>
                        </div>
                    ) : (
                        <div>
                            <h3>{album.name}</h3>
                            <button onClick={() => openAlbum(album._id)}>View</button>
                            {isMe && <button onClick={() => startEdit(album)}>Edit</button>}
                            {isMe && <button onClick={() => deleteAlbum(album._id)}>Delete</button>}
                        </div>
                    )}
                </div>
            ))}

            {selected && (
                <div>
                    <h3>Posts in {selected.name}</h3>
                    {selected.posts.length === 0 && <p>No posts saved yet</p>}
                    {selected.posts.map((post) => (
                        <div key={post._id}>
                            <PostPreview post={post} />
                            {isMe && <button onClick={() => removePost(post._id)}>Remove from album</button>}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

export default Albums;