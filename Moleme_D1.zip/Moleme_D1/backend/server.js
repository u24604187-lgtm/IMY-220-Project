const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors()); 
app.use(express.json()); 


app.post('/api/signin', (req, res) => {
    const { email, password } = req.body;

    res.json({
        success: true,
        message: `User ${username} is signed in`,
        user: {
        id: 1,
        username: "Leon",
        email: email
        }
    });
});


app.post('/api/signup', (req, res) => {
    const { username, email, password } = req.body;

    res.json({
        success: true,
        message: "Profile created successfully. Welcome to DePict",
        user: {
        id: 1,
        username: username,
        email: email
        }
    });
});

const PORT = 5000;

app.listen( PORT , () => {
    console.log(`Server running on http://localhost:${PORT}`);
});