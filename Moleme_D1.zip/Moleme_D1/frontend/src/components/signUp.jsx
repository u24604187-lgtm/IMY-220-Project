import { useState } from "react";

function SignUp() {
    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [bod, setBod] = useState("");
    const [password, setPassword] = useState("");
    const [verify, setVerify] = useState("");
    const [error, setError] = useState("");

    const handleSubmit = async(e) => {
        e.preventDefault();

        if(username === ""){
        setError("Username is required");
        return;
        }

        if(email === ""){
        setError("Email is required");
        return;
        }

        if(!email.includes("@")){
        setError("Email must include @)");
        return;
        }

        if (bod === ""){
        setError("Date of birth is required");
        return;
        }

        if (password !== verify){
        setError("Passwords do not match");
        return;
        }

        setError("");

        try{
            const response = await fetch("http://localhost:5000/api/signup", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, email, password }),
            });

            const data = await response.json();
            console.log("Sign-up response:", data);

            
        }catch (err){
            setError("Something went wrong. Please try again.");
            console.error(err);
        }

    };

    return (
        <form className="signUp" onSubmit={handleSubmit}>
        <input type="text" name="email" placeholder="email" value={email} onChange={(e) => setEmail(e.target.value)}/>
        <input type="date" name="BoD" value={bod} placeholder="date of birth" onChange={(e) => setBod(e.target.value)}/>
        <input type="text" name="username" placeholder="username" value={username} onChange={(e) => setUsername(e.target.value)}/>
        <input type="password" placeholder="password" name="passwrd" value={password} onChange={(e) => setPassword(e.target.value)}/>
        <input type="password" name="passwrdVer" placeholder="verify your password" value={verify} onChange={(e) => setVerify(e.target.value)}/>

        {error && <p style={{ color: "red" }}>{error}</p>}

        <button type="submit">Create Profile</button>
        </form>
    );
}

export default SignUp;

