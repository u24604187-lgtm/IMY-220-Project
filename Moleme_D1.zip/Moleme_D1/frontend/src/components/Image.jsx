function Image({ src, alt }) {
    return <img className="post-image" src={src} alt={alt} />;
}

export default Image;