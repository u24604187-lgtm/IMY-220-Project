import { useState } from "react";

function Login(){
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");

    const handleSubmit = async(e) => {

        e.preventDefault();

        if(email === ""){
            setError("Email is required");
            return;
        }

        if(password === ""){
            setError("Password is required");
            return;
        }

        setError("");
        
        try{
            const response = await fetch("http://localhost:5000/api/signin", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password }),
            });

            const data = await response.json();
            console.log("Sign-in response:", data);

        
        }catch (err){
            setError("Something went wrong. Please try again.");
            console.error(err);
        }
    };

    return(
        <form className="login" onSubmit={handleSubmit}>

            <input type="text" name="email" value={email} placeholder="email" onChange={(e) => setEmail(e.target.value)}/>
            <input type="password" name="passwrd" value={password} placeholder="password" onChange={(e) => setPassword(e.target.value)}/>

            {error && <p style={{ color: "red" }}>{error}</p>}

            <button type="submit">Log In</button>
        </form>
    );
}

export default Login;