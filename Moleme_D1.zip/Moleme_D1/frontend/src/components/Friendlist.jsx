import Friend from "./Friend";

function FriendList({ friends }) {
  return (
    <div className="friends-list">
      {friends.map((friend) => (
        <Friend key={friend.id} friend={friend} />
      ))}
    </div>
  );
}

export default FriendList;