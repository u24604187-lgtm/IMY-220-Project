
function Comments({ comments }){
    return(
        <div className="comments">
            <h3>Comments</h3>

            {comments.map((comment) => (
                <div key={comment.id} className="comment">
                <strong>{comment.username}</strong>
                <p>{comment.text}</p>
                </div>
            ))}
        </div>
    );
}

export default Comments;