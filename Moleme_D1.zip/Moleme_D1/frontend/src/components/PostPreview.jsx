import { Link } from "react-router-dom";

function PostPreview({ post }){
    return (
        <Link to={`/post/${post.id}`} className="Post-preview">
            <h1>{post.username}</h1>
                <img src={post.postImg} alt={post.caption} />
                <p>{post.caption}</p>
                <p>{post.likeCount} likes</p>
        </Link>
    );
}

export default PostPreview