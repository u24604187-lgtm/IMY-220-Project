

function PostPreview( {post} ){
    //const [view, changeView] = useState(null)
        return (
            <div>
                <div className="Post-pre">
                    <h1>{post.username}</h1>
                    <img src={post.postImg} />
                    <p>{post.caption}</p>
                    <p>{post.likeCount} likes</p>
                </div>
            </div>
        )
}

export default PostPreview