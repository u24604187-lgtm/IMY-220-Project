import { useState } from "react";

function CreatePost(){
    const [photo, setPhoto] = useState(null);
    const [caption, setCaption] = useState("");
    const [preview, setPreview] = useState(null);
    const [error, setError] = useState("");

    const handleFileChange = (e) => {
        const selected = e.target.files[0];
        setPhoto(selected);
        if(selected){
            setPreview(URL.createObjectURL(selected));
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if(!photo){
        setError("Select photo");
        return;
        }

        if(caption === ""){
        setError("Caption is required");
        return;
        }

        setError("");
        console.log("New post:", { photo, caption });
       
    };

    return(
        <form onSubmit={handleSubmit}>

            <input type="file" accept="image/*" onChange={handleFileChange} />
            {preview && <img src={preview} alt="preview" width="200" />}
            <textarea placeholder="Write a caption..." value={caption} onChange={(e) => setCaption(e.target.value)}/>

            {error && <p style={{ color: "red" }}>{error}</p>}

            <button type="submit">Upload Post</button>
        </form>
    );
}

export default CreatePost;