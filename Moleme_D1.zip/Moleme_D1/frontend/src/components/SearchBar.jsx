function SearchBar({ search, onSearchChange }) {
  return (
    <div className="searchBar">
      <input
        type="text"
        value={search}
        placeholder="Search..."
        onChange={(e) => onSearchChange(e.target.value)}
      />
    </div>
  );
}

export default SearchBar;