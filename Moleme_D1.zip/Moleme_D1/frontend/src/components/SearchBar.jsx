import { useState } from "react";

function SearchBar(){
    const [search, setSearch] = useState("");

    const handleChange = (e) => {
        setSearch(e.target.value);
    };

    return(
        <div className="searchBar">
        <input type="text" value={search} placeholder="Search..." onChange={handleChange}/>
        </div>
    );
}

export default SearchBar;