import { Link } from "react-router-dom";

function Navigation() {
    return (
        <nav>
            <Link to="/home">Home || </Link>
            <Link to="/posts">Posts || </Link>
            <Link to="/profile">Profile || </Link>
            <Link to="/search">Search</Link>
        </nav>
    );
}

export default Navigation;