import { useState } from "react";

function ProfilePreview(props) {
    const [view, changeView] = useState(false);

    if(view == true){
        return(
            <div>
                <h1>{props.username}</h1>
                <h2>{props.folCount}</h2>
                <img src={props.pfp} />
                <button onClick={() => changeView(false)}>Collapse</button>
            </div>
        );
    }else{
        return(
            <div>
                <h1>{props.username}</h1>
                <button onClick={() => changeView(true)}>Expand</button>
            </div>
        );
    }
}

export default ProfilePreview;