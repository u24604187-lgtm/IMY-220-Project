import { Link } from "react-router-dom";

function Friend({ friend }) {
    return(
        <Link to={`/profile/${friend.id}`} className="friend">
            <p>{friend.username}</p>
            <img src={friend.pfp} alt={friend.username} width="50" />
        </Link>
    );
}



export default Friend;