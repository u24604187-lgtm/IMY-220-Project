import { useState } from "react";
import SearchBar from "../components/SearchBar";
import ProfilePreview from "../components/ProfilePreview";

function Search() {
    const [searchTerm, setSearchTerm] = useState("");

    const profiles = [
        {id: 1, username: "alice", bio: "Loves hiking", pfp: "/avatar1.jpg", folCount: 23},
        {id: 2, username: "Thabi", bio: "Photographer", pfp: "/avatar2.jpg", folCount:80 },
    ];

    const filteredProfiles = profiles.filter((profile) =>
        profile.username.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="search-page">
        <h1>Search Profiles</h1>
        <SearchBar search={searchTerm} onSearchChange={setSearchTerm} />

        <div className="search-results">
            {filteredProfiles.map((profile) => (
            <ProfilePreview key={profile.id} {...profile} />
            ))}
        </div>
        </div>
    );
}

export default Search;