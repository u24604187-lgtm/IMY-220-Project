import { useState } from "react";
import Login from "../components/SignIn";
import SignUp from "../components/signUp";

function Splash(){

    const [activeForm, setActiveForm] = useState(null);

    return (
        <div>
            <h1>Welcome To Depict</h1>

            <div className="spalsh-buttons">
                <span>
                    <button onClick={() => setActiveForm("signup")}>Sign Up</button>
                </span>
                <span>
                    <button onClick={() => setActiveForm("login")}>Log In</button>
                </span>
            </div>

            {activeForm === "login" && <Login />}
            {activeForm === "signup" && <SignUp />}
        </div>
    );
}

export default Splash;
