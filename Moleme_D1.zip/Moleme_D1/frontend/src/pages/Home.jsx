import Feed from "../components/Feed";

function Home() {

    const posts = [
        {id: 1, username: "Alice", postImg: "/Alice1.jpg", caption: "Beautiful sunset", likeCount: 24},
        {id: 2, username: "Thabi", postImg: "/Thabi.jpg", caption: "OOTD!", likeCount: 56},
        {id: 3, username: "Leon", postImg: "/Lean.jpg", caption: "Coffee for the day", likeCount: 12},
    ];

    return(
        <div className="home">
            <h1>Depict</h1>
            <h2>Genral feed</h2>
            <Feed posts={posts} />
        </div>
    );
}

export default Home;
