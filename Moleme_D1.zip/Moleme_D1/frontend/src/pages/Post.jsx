import { useParams } from "react-router-dom";
import Image from "../components/Image";
import Comments from "../components/Comments"


function Post() {

    const { id } = useParams();

    const post = {
    id: id,
    username: "Leon",
    postImg: "Leon.img",
    caption: "Coffee to get through code",
    likeCount: 42,
    comments: [
      {id: 1, username: "Alice", text: "Nice post!"},
      {id: 2, username: "Thabi", text: "Love this."},
    ],
  };

    return (
        <div>
            <h1>{post.username}</h1>
                <Image src={post.postImg} alt={post.username}/>
                <p>{post.caption}</p>
                <p>{post.likeCount} likes</p>
                <Comments comments={post.comments}/>
        </div>
    );
}

export default Post;
