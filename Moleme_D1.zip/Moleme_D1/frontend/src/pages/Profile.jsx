import { useParams } from "react-router-dom";
import PostPreview from "../components/PostPreview";
import FriendList from "../components/Friendlist"
import CreatePost from "../components/CreatePost";


function Profile() {
    const { id } = useParams();


    const profile = {
        id: id,
        username: "Leon",
        bio: "Eat, Sleep, Breath Coffee",
        pfp: "avatar.jpg",
        followerCount: 128,
        followingCount: 97,
    };

    const posts = [
        {id: 1, username: "Leon", postImg: "", caption: "First coffee for the morning", likeCount: 12},
        {id: 2, username: "Leon", postImg: "", caption: "Afternoon joe", likeCount: 34},
    ];

    const friends = [
        {id: 1, username: "Alice", pfp: "avatar2.jpg"},
        {id: 2, username: "Thabi", pfp: "avatar3.jpg"},
    ];

    return(
        <div className="profile-page">
            <img src={profile.pfp} alt={profile.username} width="150" />
            <h1>{profile.username}</h1>
            <p>{profile.bio}</p>

            <div className="follows">
                <span>{profile.followerCount} followers</span>
                <span>{profile.followingCount} following</span>
            </div>

            <h1>Posts</h1>
            <div>
                {posts.map((post) => (
                <PostPreview key={post.id} post={post} />
                ))}
            </div>

            <h2>Friends</h2>
            <FriendList friends={friends} />

            <h2>Create a Post</h2>
            <CreatePost />

        </div>
    );
}

export default Profile;
