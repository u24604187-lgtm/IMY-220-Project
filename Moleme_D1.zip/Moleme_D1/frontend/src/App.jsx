import { useState } from 'react'

import {
    BrowserRouter,
    Routes,
    Route
} from "react-router-dom";

//import './App.css'

import Home from "./pages/Home";
import Splash from "./pages/Splash"
import Profile from "./pages/Profile";
import Navigation from "./components/Navigation";
import NotFound from "./pages/NotFound";
import Post from "./pages/Post";
import SearchBar from './components/SearchBar';

function App() {
  //const [count, setCount] = useState(0)

  return (
    <BrowserRouter>
            <Navigation />

            <Routes>
              <Route path="/" element={<Splash />} />

              
              <Route path="/home" element={<Home />} />
              <Route path="/posts" element={<Post />} /> 
              <Route path="/profile" element={<Profile />} />
              <Route path="/search" element={<SearchBar />} /> 
              <Route path="*" element={<NotFound />} />
          </Routes>

        </BrowserRouter>
  );
}

export default App
