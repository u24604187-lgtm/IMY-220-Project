import { useState } from "react";
import Login from "../components/SignIn";
import SignUp from "../components/signUp";

function Splash() {
    const [activeForm, setActiveForm] = useState(null);

return (
    <div className="relative min-h-screen w-full">
    
        <div
            className="fixed inset-0 bg-cover bg-center bg-no-repeat"
            style={{ backgroundImage: "url('/depict-background.jpeg')" }}
        />

  
        <div className="fixed inset-0 bg-black/50" />

     
        <div className="relative z-10 flex min-h-screen flex-col items-center justify-center px-6 py-10 text-center text-white">
            <h1 className="mb-8 text-4xl text-[#E89EC4] font-bold sm:text-6xl">
                Welcome To Depict
            </h1>

            <div className="mb-8 flex flex-wrap justify-center gap-4">
                <button
                    onClick={() => setActiveForm("signup")}
                    className="rounded-lg bg-[#A75879] px-8 py-3 font-semibold text-white transition hover:bg-purple-700"
                >
                    Sign Up
                </button>

                <button
                    onClick={() => setActiveForm("login")}
                    className="rounded-lg bg-[#A75879] px-8 py-3 font-semibold text-white transition hover:bg-white hover:text-gray-900"
                >
                    Log In
                </button>
            </div>

            {activeForm === "login" && (
                <div className="w-full max-w-lg rounded-xl bg-white p-6 text-gray-900 shadow-xl">
                    <Login />
                </div>
            )}

            {activeForm === "signup" && (
                <div className="w-full max-w-lg rounded-xl bg-white p-6 text-gray-900 shadow-xl">
                    <SignUp />
                </div>
            )}
        </div>
    </div>
);
}

export default Splash;