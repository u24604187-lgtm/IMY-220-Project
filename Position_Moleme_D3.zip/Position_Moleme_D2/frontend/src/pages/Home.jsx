import { useEffect, useState } from "react";
import Feed from "../components/Feed";



function Home() {
    const user = JSON.parse(localStorage.getItem("user"));
    const [scope, setScope] = useState("global");
    const [items, setItems] = useState([]);
    const [error, setError] = useState("");

    useEffect(() => {
        async function loadFeed(){
            try{
                const response = await fetch(`http://localhost:5000/api/activity?scope=${scope}`, {
                    headers: { "x-user-id": user._id },
                });
                const data = await response.json();

                if(!response.ok){
                    setError(data.error);
                    return;
                }

                setError("");
                setItems(data);
            }catch(err){
                setError("Could not load the feed");
            }
        }

        loadFeed();
    }, [scope]);

    return(
    <div className="min-h-screen w-full bg-[#E07B9E] m-0 p-0">
        <div className="home" >
            <h1>Depict</h1>

            <div className="mb-8 flex flex-wrap justify-center gap-4">
            <div className="text-white border rounded-lg bg-[#A75879] px-8 py-3 font-semibold text-white transition hover:bg-purple-700">
                <button onClick={() => setScope("global")}>Global feed</button>
                
            </div>
           
           
             <div className="text-white border rounded-lg bg-[#A75879] px-8 py-3 font-semibold text-white transition hover:bg-purple-700">
                 <button onClick={() => setScope("local")}>Friends' posts</button>
                
            </div>
        </div>
            <h2>{scope === "global" ? "Global feed" : "Friends' posts"}</h2>

            {error && <p style={{ color: "red" }}>{error}</p>}
            <Feed items={items} />
        </div>
    </div>
    );
}

export default Home;
