import { useEffect, useState } from "react";
import SearchBar from "../components/SearchBar";
import ProfilePreview from "../components/ProfilePreview";

function Search() {
    const user = JSON.parse(localStorage.getItem("user"));
    const [searchTerm, setSearchTerm] = useState("");
    const [profiles, setProfiles] = useState([]);
    const [error, setError] = useState("");

    useEffect(() => {
        async function loadUsers(){
            try{
                const response = await fetch("http://localhost:5000/api/users", {
                    headers: { "x-user-id": user._id },
                });
                const data = await response.json();

                if(!response.ok){
                    setError(data.error);
                    return;
                }

                setProfiles(data);
            }catch(err){
                setError("Could not load users");
            }
        }

        loadUsers();
    }, []);

    const filteredProfiles = profiles.filter((profile) =>
        profile.username.toLowerCase().includes(searchTerm.toLowerCase())
    );

    
return (
    <div className="mx-auto min-h-screen max-w-5xl px-6 py-8">
        <h1 className="mb-6 text-3xl font-bold text-white">
            Search Profiles
        </h1>

        <div className="mb-8 max-w-md">
            <SearchBar
                search={searchTerm}
                onSearchChange={setSearchTerm}
            />
        </div>

        {error && (
            <p className="mb-4 text-sm text-red-600">
                {error}
            </p>
        )}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {filteredProfiles.map((profile) => (
                <ProfilePreview
                    key={profile._id}
                    {...profile}
                />
            ))}
        </div>

        {!error && filteredProfiles.length === 0 && (
            <p className="mt-6 text-white">
                No profiles found.
            </p>
        )}
    </div>
);

}

export default Search;