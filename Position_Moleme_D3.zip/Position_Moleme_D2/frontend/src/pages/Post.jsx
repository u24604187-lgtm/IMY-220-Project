import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import Image from "../components/Image";
import Comments from "../components/Comments";

const API = "http://localhost:5000/api";

function Post() {
    const { id } = useParams();
    const navigate = useNavigate();
    const user = JSON.parse(localStorage.getItem("user"));
    const headers = { "Content-Type": "application/json", "x-user-id": user._id };

    const [post, setPost] = useState(null);
    const [error, setError] = useState("");
    const [message, setMessage] = useState("");
    const [editing, setEditing] = useState(false);
    const [caption, setCaption] = useState("");
    const [reasons, setReasons] = useState([]);
    const [reason, setReason] = useState("");
    const [albums, setAlbums] = useState([]);
    const [albumId, setAlbumId] = useState("");

    async function loadPost(){
        try{
            const response = await fetch(`${API}/posts/${id}`, { headers });
            const data = await response.json();

            if(!response.ok){
                setError(data.error);
                return;
            }

            setPost(data);
            setCaption(data.caption);
        }catch(err){
            setError("Could not load the post");
        }
    }

    async function loadAlbums(){
        try{
            const albumsRes = await fetch(`${API}/albums?userId=${user._id}`, { headers });

            if(albumsRes.ok){
                setAlbums(await albumsRes.json());
            }
        }catch(err){
            console.error(err);
        }
    }

    async function loadReason(){
        try{
            const reasonsRes = await fetch(`${API}/report-reasons`, { headers });

            if(reasonsRes.ok){
                setReasons(await reasonsRes.json());
            }
        }catch(err){
            console.error(err);
        }
    }

    useEffect(() => {
        loadPost();
        loadAlbums();
        loadReason();
    }, [id]);

    async function saveCaption(){
        if(caption === ""){
            setMessage("Caption is required");
            return;
        }

        const response = await fetch(`${API}/posts/${id}`, {
            method: "PUT",
            headers,
            body: JSON.stringify({ caption }),
        });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        setPost(data);
        setEditing(false);
        setMessage("");
    }

    async function toggleLike(){
        const response = await fetch(`${API}/posts/${id}/like`, { method: "POST", headers });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        setPost(data);
    }

    async function deletePost(){
        const response = await fetch(`${API}/posts/${id}`, { method: "DELETE", headers });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        navigate(`/profile/${user._id}`);
    }

    async function reportPost(){
        if(reason === ""){
            setMessage("Select the reason for your report");
            return;
        }

        const response = await fetch(`${API}/posts/${id}/report`, {
            method: "POST",
            headers,
            body: JSON.stringify({ reason }),
        });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        setReason("");
        setMessage("Post reported");
    }

    async function saveToAlbum(){
        if(albumId === ""){
            setMessage("Pick the album you wish to save this post on");
            return;
        }

        const response = await fetch(`${API}/albums/${albumId}/posts/${id}`, {
            method: "POST",
            headers,
        });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        setMessage("Saved to album");
    }

    if(error){
        return <p className="p-4 text-red-600">{error}</p>;
    }

    if(!post){
        return <p className="p-4">Loading...</p>;
    }

    const isOwner = post.userId === user._id;

    const btn = "rounded bg-blue-500 px-3 py-1 text-sm text-white hover:bg-blue-600";
    const btnGray = "rounded bg-[#E8B59E] px-3 py-1 text-sm hover:bg-gray-300";
    const btnRed = "rounded bg-red-500 px-3 py-1 text-sm text-white hover:bg-red-600";
    const field = "rounded border border-white px-2 py-1";

    return (
        <div className="mx-auto max-w-2xl space-y-6 p-4">
            <h1 className="text-2xl font-bold text-white">
                <Link to={`/profile/${post.userId}`} className="hover:underline">{post.username}</Link>
            </h1>

            <Image src={post.image} alt={post.caption} className="w-full rounded-lg" />

            {editing ? (
                <div className="space-y-2">
                    <textarea
                        className={`${field} w-full`}
                        rows="3"
                        value={caption}
                        onChange={(e) => setCaption(e.target.value)}
                    />
                    <div className="flex gap-2">
                        <button className={btn} onClick={saveCaption}>Save</button>
                        <button className={btnGray} onClick={() => setEditing(false)}>Cancel</button>
                    </div>
                </div>
            ) : (
                <p className="text-lg">{post.caption}</p>
            )}

            <div className="flex items-center gap-3">
                <button className={btn} onClick={toggleLike}>{post.liked ? "Unlike" : "Like"}</button>
                <span className="text-white">{post.likeCount} likes</span>
            </div>

            {isOwner && !editing && (
                <div className="flex gap-2">
                    <button className={btnGray} onClick={() => setEditing(true)}>Edit caption</button>
                    <button className={btnRed} onClick={deletePost}>Delete post</button>
                </div>
            )}

            <div className="flex items-center gap-2">
                <select className={field} value={albumId} onChange={(e) => setAlbumId(e.target.value)}>
                    <option value="">Save to album...</option>
                    {albums.map((album) => (
                        <option key={album._id} value={album._id}>{album.name}</option>
                    ))}
                </select>
                <button className={btn} onClick={saveToAlbum}>Save</button>
            </div>

            {!isOwner && (
                <div className="report space-y-2">
                    <h3 className="text-lg font-semibold">Report this post</h3>
                    <div className="flex items-center gap-2">
                        <select className={field} value={reason} onChange={(e) => setReason(e.target.value)}>
                            <option value="">Select a reason...</option>
                            {reasons.map((r) => (
                                <option key={r._id} value={r.reason}>{r.reason}</option>
                            ))}
                        </select>
                        <button className={btnRed} onClick={reportPost}>Report</button>
                    </div>
                </div>
            )}

            {message && <p className="text-sm text-white">{message}</p>}

            <Comments comments={post.comments} postId={id} onAdded={loadPost} />
        </div>
    );
}

export default Post;