import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import PostPreview from "../components/PostPreview";
import Friendlist from "../components/Friendlist";
import CreatePost from "../components/CreatePost";
import Album from "../components/Album";
import Avatar from "../components/Avatar";

const API = "http://localhost:5000/api";

function Profile() {
    const { id } = useParams();
    const navigate = useNavigate();
    const stored = JSON.parse(localStorage.getItem("user"));
    const headers = { "Content-Type": "application/json", "x-user-id": stored._id };
    const isMe = id === stored._id;

    const [profile, setProfile] = useState(null);
    const [me, setMe] = useState(null);
    const [posts, setPosts] = useState([]);
    const [friends, setFriends] = useState([]);
    const [requests, setRequests] = useState([]);
    const [visible, setVisible] = useState(9);
    const [editing, setEditing] = useState(false);
    const [username, setUsername] = useState("");
    const [bio, setBio] = useState("");
    const [pronouns, setPronouns] = useState("");
    const [linksText, setLinksText] = useState("");
    const [pfpFile, setPfpFile] = useState(null);
    const [error, setError] = useState("");
    const [message, setMessage] = useState("");

    async function loadAll(){
        try{
            const [profileRes, meRes, postsRes] = await Promise.all([
                fetch(`${API}/users/${id}`, { headers }),
                fetch(`${API}/me`, { headers }),
                fetch(`${API}/posts?userId=${id}`, { headers }),
            ]);

            if(!profileRes.ok){
                setError("Profile not found");
                return;
            }

            const meData = await meRes.json();
            setProfile(await profileRes.json());
            setMe(meData);
            setPosts(await postsRes.json());
            setError("");

            // only friends (and yourself) may see the friends list
            if(isMe || meData.friends.includes(id)){
                const friendsRes = await fetch(`${API}/users/${id}/friends`, { headers });
                if(friendsRes.ok){
                    setFriends(await friendsRes.json());
                }
            }else{
                setFriends([]);
            }

            if(isMe){
                const requestsRes = await fetch(`${API}/friend-requests`, { headers });
                if(requestsRes.ok){
                    setRequests(await requestsRes.json());
                }
            }
        }catch(err){
            setError("Could not load the profile");
        }
    }

    useEffect(() => {
        setEditing(false);
        setMessage("");
        setVisible(9);
        loadAll();
    }, [id]);

    function startEditing(){
        setUsername(profile.username);
        setBio(profile.bio || "");
        setPronouns(profile.pronouns || "");
        setLinksText((profile.links || []).join("\n"));
        setPfpFile(null);
        setEditing(true);
    }

    async function saveProfile(){
        if(username === ""){
            setMessage("Username is required");
            return;
        }

        const formData = new FormData();
        formData.append("username", username);
        formData.append("bio", bio);
        formData.append("pronouns", pronouns);
        formData.append("links", linksText);
        if(pfpFile){
            formData.append("profilePicture", pfpFile);
        }

        const response = await fetch(`${API}/users/${id}`, {
            method: "PUT",
            headers: { "x-user-id": stored._id }, // no Content-Type for FormData
            body: formData,
        });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        localStorage.setItem("user", JSON.stringify(data));
        setEditing(false);
        setMessage("");
        loadAll();
    }

    async function deleteProfile(){
        if(!window.confirm("Delete your profile? This cannot be undone.")){
            return;
        }

        const response = await fetch(`${API}/users/${id}`, { method: "DELETE", headers });

        if(!response.ok){
            const data = await response.json();
            setMessage(data.error);
            return;
        }

        localStorage.removeItem("user");
        navigate("/");
    }

    async function sendRequest(){
        const response = await fetch(`${API}/users/${id}/friend-request`, { method: "POST", headers });
        const data = await response.json();

        if(!response.ok){
            setMessage(data.error);
            return;
        }

        setMessage("");
        loadAll();
    }

    async function unfriend(){
        if(!window.confirm(`Unfriend ${profile.username}?`)){
            return;
        }

        await fetch(`${API}/users/${id}/friend`, { method: "DELETE", headers });
        loadAll();
    }

    async function answerRequest(fromId, action){
        await fetch(`${API}/users/${fromId}/${action}`, { method: "POST", headers });
        loadAll();
    }

    if(error){
        return <p className="error">{error}</p>;
    }

    if(!profile || !me){
        return <p>Loading...</p>;
    }

    const isFriend = me.friends.includes(id);
    const theySentRequest = me.friendRequests.includes(id);
    const canSeeFull = isMe || isFriend;

    let status = "Not friends";
    if(isFriend){
        status = "Friends";
    }else if(theySentRequest){
        status = `${profile.username} sent you a friend request`;
    }else if(profile.requestSent){
        status = "Friend request pending";
    }

    const btn = "rounded bg-blue-500 px-3 py-1 text-sm text-white hover:bg-blue-600";
    const btnGray = "rounded bg-gray-200 px-3 py-1 text-sm hover:bg-gray-300";
    const btnRed = "rounded bg-red-500 px-3 py-1 text-sm text-white hover:bg-red-600";

    return(
        <div className="text-white">
        <div className="profile-page mx-auto max-w-5xl space-y-4 p-4">
            <div className="flex items-center gap-4">
                <Avatar src={profile.profilePicture} name={profile.username} size="large" />
                <h1 className="text-2xl font-bold">{profile.username}</h1>
            </div>

            {canSeeFull && profile.pronouns && <p>{profile.pronouns}</p>}
            {canSeeFull && profile.bio && <p>{profile.bio}</p>}
            {canSeeFull && profile.links && profile.links.map((link) => (
                <p key={link}><a href={link} target="_blank" rel="noreferrer" className="text-blue-600 underline">{link}</a></p>
            ))}

            {message && <p className="text-red-600">{message}</p>}

            {isMe && !editing && (
                <div className="flex gap-2">
                    <button className={btn} onClick={startEditing}>Edit profile</button>
                    <button className={btnRed} onClick={deleteProfile}>Delete profile</button>
                </div>
            )}

            {isMe && editing && (
                <div className="edit-profile flex max-w-md flex-col gap-2">
                    <label htmlFor="username">Username</label>
                    <input id="username" className="rounded border p-1" value={username} onChange={(e) => setUsername(e.target.value)} />

                    <label htmlFor="pronouns">Pronouns</label>
                    <input id="pronouns" className="rounded border p-1" value={pronouns} placeholder="e.g. she/her" onChange={(e) => setPronouns(e.target.value)} />

                    <label htmlFor="bio">Bio</label>
                    <textarea id="bio" className="rounded border p-1" value={bio} onChange={(e) => setBio(e.target.value)} />

                    <label htmlFor="links">Social media links (one per line)</label>
                    <textarea id="links" className="rounded border p-1" value={linksText} placeholder="https://instagram.com/you" onChange={(e) => setLinksText(e.target.value)} />

                    <label htmlFor="pfp">Profile picture</label>
                    <input id="pfp" type="file" accept="image/*" onChange={(e) => setPfpFile(e.target.files[0] || null)} />

                    <div className="flex gap-2">
                        <button className={btn} onClick={saveProfile}>Save</button>
                        <button className={btnGray} onClick={() => setEditing(false)}>Cancel</button>
                    </div>
                </div>
            )}

            {!isMe && (
                <div className="friend-status">
                    <p><strong>{status}</strong></p>
                    {isFriend && <button className={btnRed} onClick={unfriend}>Unfriend</button>}
                    {!isFriend && theySentRequest && (
                        <div className="flex gap-2">
                            <button className={btn} onClick={() => answerRequest(id, "accept")}>Accept request</button>
                            <button className={btnGray} onClick={() => answerRequest(id, "decline")}>Decline</button>
                        </div>
                    )}
                    {!isFriend && !theySentRequest && !profile.requestSent && (
                        <button className={btn} onClick={sendRequest}>Add friend</button>
                    )}
                </div>
            )}

            {!canSeeFull && <p>Become friends with {profile.username} to see their full profile.</p>}

            {isMe && requests.length > 0 && (
                <div>
                    <h2 className="text-xl font-semibold">Friend requests</h2>
                    {requests.map((r) => (
                        <div key={r._id} className="flex items-center gap-2 py-1">
                            <span>{r.username}</span>
                            <button className={btn} onClick={() => answerRequest(r._id, "accept")}>Accept</button>
                            <button className={btnGray} onClick={() => answerRequest(r._id, "decline")}>Decline</button>
                        </div>
                    ))}
                </div>
            )}

            <h2 className="text-xl font-semibold">Posts ({posts.length})</h2>
            <div className="grid grid-cols-3 gap-4">
                {posts.slice(0, visible).map((post) => (
                    <PostPreview key={post._id} post={post} />
                ))}
            </div>
            {visible < posts.length && (
                <button className={btnGray} onClick={() => setVisible(visible + 9)}>Show more</button>
            )}

            {canSeeFull && (
                <div>
                    <h2 className="text-xl font-semibold">Friends ({friends.length})</h2>
                    <Friendlist friends={friends} />
                </div>
            )}

            <Album userId={id} isMe={isMe} />

            {isMe && (
                <div>
                    <h2 className="text-xl font-semibold">Create a Post</h2>
                    <CreatePost onCreated={loadAll} />
                </div>
            )}
        </div>
        </div>
    );
}

export default Profile;