import Friend from "./Friend";

function Friendlist({ friends }) {
  return (
    <div className="friends-list">
      {friends.map((friend) => (
        <Friend key={friend._id} friend={friend} />
      ))}
    </div>
  );
}

export default Friendlist;