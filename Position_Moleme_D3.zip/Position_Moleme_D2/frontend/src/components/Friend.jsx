import { Link } from "react-router-dom";
import Avatar from "./Avatar";

function Friend({ friend }) {
    return(
        <Link to={`/profile/${friend._id}`} className="friend">
            <Avatar src={friend.profilePicture} name={friend.username} />
            <p>{friend.username}</p>
        </Link>
    );
}

export default Friend;