import { useState } from "react";
import { useNavigate } from "react-router-dom";

function signUp() {
    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [bod, setBod] = useState("");
    const [password, setPassword] = useState("");
    const [verify, setVerify] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleSubmit = async(e) => {
        e.preventDefault();

        if(username === ""){
        setError("Username is required");
        return;
        }

        if(email === ""){
        setError("Email is required");
        return;
        }

        if(!email.includes("@")){
        setError("Email must include @)");
        return;
        }

        if (bod === ""){
        setError("Date of birth is required");
        return;
        }

        if(password === ""){
            setError("Password is required");
            return;
        }

        if (password !== verify){
        setError("Passwords do not match");
        return;
        }

        setError("");

       try{
            const response = await fetch("http://localhost:5000/api/signup", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, email, password }),
            });

            const data = await response.json();

            if(!response.ok){
                setError(data.error);
                return;
            }

            localStorage.setItem("user", JSON.stringify(data.user));
            navigate("/home");
        }catch (err){
            setError("Something went wrong. Please try again.");
        }

    };


return (
    <form
        className="flex w-full flex-col gap-4"
        onSubmit={handleSubmit}
    >
        <input
            type="text"
            name="username"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full bg-[#E89EB8] text-[#f7f5f7] rounded-lg px-4 py-3 outline-none focus:border-[#f7f5f7] focus:ring-2 focus-[#f7f5f7]"
        />

        <input
            type="email"
            name="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-[#E89EB8] text-[#f7f5f7] rounded-lg px-4 py-3 outline-none focus:border-[#f7f5f7] focus:ring-2 focus-[#f7f5f7]"
        />

        <input
            type="date"
            name="BoD"
            value={bod}
            onChange={(e) => setBod(e.target.value)}
            className="w-full bg-[#E89EB8] text-[#f7f5f7] rounded-lg px-4 py-3 outline-none focus:border-[#f7f5f7] focus:ring-2 focus-[#f7f5f7]"
        />

        <input
            type="password"
            name="passwrd"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-[#E89EB8] text-[#f7f5f7] rounded-lg px-4 py-3 outline-none focus:border-[#f7f5f7] focus:ring-2 focus-[#f7f5f7]"
        />

        <input
            type="password"
            name="passwrdVer"
            placeholder="Verify your password"
            value={verify}
            onChange={(e) => setVerify(e.target.value)}
            className="w-full bg-[#E89EB8] text-[#f7f5f7] rounded-lg px-4 py-3 outline-none focus:border-[#f7f5f7] focus:ring-2 focus-[#f7f5f7]"
        />

        {error && (
            <p className="text-sm text-red-600">{error}</p>
        )}

        <button
            type="submit"
            className="w-full rounded-lg bg-purple-600 px-4 py-3 font-semibold text-white transition hover:bg-purple-700"
        >
            Create Profile
        </button>
    </form>
);

}

export default signUp;

