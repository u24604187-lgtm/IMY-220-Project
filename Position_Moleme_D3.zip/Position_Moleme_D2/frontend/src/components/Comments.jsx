import { useState } from "react";

function Comments({ comments, postId, onAdded }){
    const user = JSON.parse(localStorage.getItem("user"));
    const [text, setText] = useState("");
    const [error, setError] = useState("");

    const handleSubmit = async(e) => {
        e.preventDefault();

        if(text === ""){
            setError("You have not written a comment yet");
            return;
        }

        try{
            const response = await fetch(`http://localhost:5000/api/posts/${postId}/comments`, {
                method: "POST",
                headers: { "Content-Type": "application/json", "x-user-id": user._id },
                body: JSON.stringify({ text }),
            });

            const data = await response.json();

            if(!response.ok){
                setError(data.error);
                return;
            }

            setText("");
            setError("");
            onAdded();
        }catch(err){
            setError("Could not add comment");
        }
    };

    return(
    <div className="comments space-y-4">
        <h2 className="text-xl font-semibold">Comments</h2>

        <div className="space-y-3">
            {comments.map((comment) => (
                <div key={comment._id} className="rounded-lg bg-gray-100 p-3">
                    <strong>{comment.username}</strong>
                    <p>{comment.text}</p>
                </div>
            ))}
        </div>

        <form onSubmit={handleSubmit} className="flex gap-2">
            <label htmlFor="comment" className="sr-only">Add a comment</label>
            <input
                id="comment"
                className="flex-1 rounded border border-gray-300 px-2 py-1"
                value={text}
                placeholder="Add a comment..."
                onChange={(e) => setText(e.target.value)}
            />
            <button type="submit" className="rounded bg-blue-500 px-3 py-1 text-sm text-white hover:bg-blue-600">
                Comment
            </button>
        </form>
        {error && <p className="text-red-600">{error}</p>}
    </div>
);
}

export default Comments;