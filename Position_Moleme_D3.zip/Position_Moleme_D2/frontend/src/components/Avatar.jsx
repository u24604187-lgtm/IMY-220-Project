
const upload = "http://localhost:5000/uploads";

function Avatar({ src, name, size = "small" }) {
    const sizeClasses = {
        small: "h-10 w-10 text-sm",
        medium: "h-14 w-14 text-lg",
        large: "h-24 w-24 text-2xl",
    };

    const classes = `shrink-0 ${sizeClasses[size] || sizeClasses.small} rounded-full object-cover`;

    if (src) {
        return (
            <img
                className={classes}
                src={`${upload}/${src}`}
                alt={name}
            />
        );
    }

    return (
        <div
            className={`${classes} flex items-center justify-center bg-gray-200 font-semibold text-gray-600`}
        >
            {name?.charAt(0).toUpperCase() || "?"}
        </div>
    );
}

export default Avatar;
