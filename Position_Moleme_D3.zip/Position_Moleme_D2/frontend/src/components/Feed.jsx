import PostPreview from "./PostPreview";

function Feed({ items }){
    const withPost = items.filter((item) => item.post);
    const textOnly = items.filter((item) => !item.post);

    return(
        <div className="space-y-6">
            {textOnly.length > 0 && (
                <ul className="space-y-1 text-sm text-white">
                    {textOnly.map((item) => (
                        <li key={item._id}>
                            <strong>{item.username}</strong> {item.text}
                        </li>
                    ))}
                </ul>
            )}

            <div className="grid grid-cols-3 gap-4">
                {withPost.map((item) => (
                    <div key={item._id} className="flex min-w-0 flex-col gap-2">
                        <p className="truncate text-sm">
                            <strong>{item.username}</strong> {item.text}
                        </p>
                        <PostPreview post={item.post} />
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Feed;