import { useState } from "react";
import { useNavigate } from "react-router-dom";

function SignIn(){
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleSubmit = async(e) => {

        e.preventDefault();

        if(email === ""){
            setError("Email is required");
            return;
        }

        if(password === ""){
            setError("Password is required");
            return;
        }

        setError("");
        
        try{
            const response = await fetch("http://localhost:5000/api/signin", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password }),
            });

            const data = await response.json();
            console.log("Sign-in response:", data);

            if(!response.ok){
                setError(data.error);
                return;
            }

            localStorage.setItem("user", JSON.stringify(data.user));
            navigate("/home");
        
        }catch (err){
            setError("Something went wrong. Please try again.");
            console.error(err);
        }
    };

    return(
        <form className="login" onSubmit={handleSubmit}>

            <input type="text" name="email" value={email} placeholder="email" onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-[#E89EB8] text-[#f7f5f7] rounded-lg px-4 py-3 outline-none focus:border-[#f7f5f7] focus:ring-2 focus-[#f7f5f7]"
        />
            <input type="password" name="passwrd" value={password} placeholder="password" onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-[#E89EB8] text-[#f7f5f7] rounded-lg px-4 py-3 outline-none focus:border-[#f7f5f7] focus:ring-2 focus-[#f7f5f7]"
        />

            {error && <p style={{ color: "red" }}>{error}</p>}

            <button type="submit" className="w-full rounded-lg bg-purple-600 px-4 py-3 font-semibold text-white transition hover:bg-purple-700"
        
            >Log In
            </button>
        </form>
    );
}

export default SignIn;