
import { Link } from "react-router-dom";
import Avatar from "./Avatar";

function ProfilePreview({ _id, username, profilePicture }) {
    return (
        <div className="flex items-center gap-3 rounded-lg border border-gray-200 bg-[#F6D9E3] p-4 shadow-sm">
            <Avatar
                src={profilePicture}
                name={username}
                size="small"
            />

            <div className="min-w-0 flex-1">
                <h2 className="truncate font-semibold text-gray-800">
                    {username}
                </h2>

                <Link
                    to={`/profile/${_id}`}
                    className="mt-1 inline-block text-sm text-blue-600 hover:text-blue-800 hover:underline"
                >
                    View profile
                </Link>
            </div>
        </div>
    );
}

export default ProfilePreview;
