import { Link } from "react-router-dom";
import Image from "./Image";

function PostPreview({ post }){
    return (
        <Link
            to={`/post/${post._id}`}
            className="block overflow-hidden rounded-lg bg-[#F6D9E3] transition hover:shadow-md"
        >
            <Image src={post.image} alt={post.caption} className="aspect-square w-full object-cover" />
            <div className="p-3">
                <h3 className="truncate font-semibold text-black">{post.username}</h3>
                <p className="truncate text-sm text-black">{post.caption}</p>
                <p className="text-sm text-black">{post.likeCount} likes</p>
            </div>
        </Link>
    );
}

export default PostPreview;