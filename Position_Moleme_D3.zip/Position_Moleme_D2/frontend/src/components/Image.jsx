const UPLOADS = "http://localhost:5000/uploads";

function Image({ src, alt, className = "w-full" }) {
    return <img className={className} src={`${UPLOADS}/${src}`} alt={alt} />;
}

export default Image;