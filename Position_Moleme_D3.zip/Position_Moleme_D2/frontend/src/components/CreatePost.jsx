import { useState } from "react";
import { useNavigate } from "react-router-dom";

const API = "http://localhost:5000/api";

function CreatePost({ onCreated }){
    const navigate = useNavigate();
    const user = JSON.parse(localStorage.getItem("user"));

    const [photo, setPhoto] = useState(null);
    const [caption, setCaption] = useState("");
    const [preview, setPreview] = useState(null);
    const [error, setError] = useState("");
    const [inputKey, setInputKey] = useState(0); // changing this clears the file input

    const handleFileChange = (e) => {
        const selected = e.target.files[0];
        setPhoto(selected || null);

        if(preview){
            URL.revokeObjectURL(preview); // free the old preview
        }
        setPreview(selected ? URL.createObjectURL(selected) : null);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if(!photo){
            setError("Select photo");
            return;
        }

        if(caption === ""){
            setError("Caption is required");
            return;
        }

        setError("");

        const formData = new FormData();
        formData.append("caption", caption);
        formData.append("image", photo); // must match .single("image")

        try{
            const response = await fetch(`${API}/posts`, {
                method: "POST",
                headers: { "x-user-id": user._id }, // no Content-Type
                body: formData,
            });
            const data = await response.json();

            if(!response.ok){
                setError(data.error);
                return;
            }

            if(onCreated){
                onCreated();
                setPhoto(null);
                setPreview(null);
                setCaption("");
                setInputKey((k) => k + 1);
            }else{
                navigate(`/post/${data._id}`);
            }
        }catch(err){
            setError("Could not create the post");
        }
    };

    return(
        <form onSubmit={handleSubmit}>
            <input key={inputKey} type="file" accept="image/*" onChange={handleFileChange} />
            {preview && <img src={preview} alt="preview" width="200" />}
            <textarea placeholder="Write a caption..." value={caption} onChange={(e) => setCaption(e.target.value)}/>

            {error && <p style={{ color: "red" }}>{error}</p>}

            <button type="submit">Upload Post</button>
        </form>
    );
}

export default CreatePost;