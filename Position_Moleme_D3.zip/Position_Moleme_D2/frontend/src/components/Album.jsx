import { useEffect, useState } from "react";
import PostPreview from "./PostPreview";
import Image from "./Image";

const API = "http://localhost:5000/api";

function Album({ userId, isMe }){
    const user = JSON.parse(localStorage.getItem("user"));
    const headers = { "Content-Type": "application/json", "x-user-id": user._id };

    const [albums, setAlbums] = useState([]);
    const [selected, setSelected] = useState(null);
    const [myPosts, setMyPosts] = useState([]);
    const [name, setName] = useState("");
    const [editingId, setEditingId] = useState(null);
    const [editName, setEditName] = useState("");
    const [error, setError] = useState("");

    async function loadAlbums(){
        try{
            const response = await fetch(`${API}/albums?userId=${userId}`, { headers });

            if(response.ok){
                setAlbums(await response.json());
            }
        }catch(err){
            setError("Could not load albums");
        }
    }

    useEffect(() => {
        setSelected(null);
        loadAlbums();
    }, [userId]);

    async function openAlbum(albumId){
        const response = await fetch(`${API}/albums/${albumId}`, { headers });

        if(response.ok){
            setSelected(await response.json());
        }

        // load fresh each time so newly created posts show up
        if(isMe){
            const postsRes = await fetch(`${API}/posts?userId=${userId}`, { headers });
            if(postsRes.ok){
                setMyPosts(await postsRes.json());
            }
        }
    }

    async function addPost(postId){
        const response = await fetch(`${API}/albums/${selected._id}/posts/${postId}`, {
            method: "POST",
            headers,
        });
        const data = await response.json();

        if(!response.ok){
            setError(data.error);
            return;
        }

        setError("");
        setSelected(data);
    }

    async function createAlbum(e){
        e.preventDefault();

        if(name === ""){
            setError("Album name is required");
            return;
        }

        const response = await fetch(`${API}/albums`, {
            method: "POST",
            headers,
            body: JSON.stringify({ name }),
        });
        const data = await response.json();

        if(!response.ok){
            setError(data.error);
            return;
        }

        setName("");
        setError("");
        loadAlbums();
    }

    function startEdit(album){
        setEditingId(album._id);
        setEditName(album.name);
    }

    async function saveAlbum(albumId){
        if(editName === ""){
            setError("Album name is required");
            return;
        }

        const response = await fetch(`${API}/albums/${albumId}`, {
            method: "PUT",
            headers,
            body: JSON.stringify({ name: editName }),
        });
        const data = await response.json();

        if(!response.ok){
            setError(data.error);
            return;
        }

        setEditingId(null);
        setError("");
        loadAlbums();

        if(selected && selected._id === albumId){
            openAlbum(albumId);
        }
    }

    async function deleteAlbum(albumId){
        const response = await fetch(`${API}/albums/${albumId}`, { method: "DELETE", headers });

        if(!response.ok){
            const data = await response.json();
            setError(data.error);
            return;
        }

        if(selected && selected._id === albumId){
            setSelected(null);
        }
        loadAlbums();
    }

    async function removePost(postId){
        const response = await fetch(`${API}/albums/${selected._id}/posts/${postId}`, {
            method: "DELETE",
            headers,
        });

        if(response.ok){
            setSelected(await response.json());
        }
    }

    // your posts that are not already in the open album
    const addable = selected
        ? myPosts.filter((p) => !selected.posts.some((sp) => sp._id === p._id))
        : [];

    const btn = "rounded bg-blue-500 px-3 py-1 text-sm text-white hover:bg-blue-600";
    const btnGray = "rounded bg-gray-200 px-3 py-1 text-sm hover:bg-gray-300";
    const btnRed = "rounded bg-red-500 px-3 py-1 text-sm text-white hover:bg-red-600";
    const input = "rounded border border-gray-300 px-2 py-1";

    return(
        <div className="albums space-y-6">
            <h2 className="text-xl font-semibold">Albums</h2>
            {error && <p className="text-red-600">{error}</p>}

            {isMe && (
                <form onSubmit={createAlbum} className="flex gap-2">
                    <input
                        className={`${input} w-64`}
                        value={name}
                        placeholder="Album name"
                        onChange={(e) => setName(e.target.value)}
                    />
                    <button type="submit" className={btn}>Create album</button>
                </form>
            )}

            <div className="space-y-3">
                {albums.map((album) => (
                    <div key={album._id} className="rounded-lg border border-gray-200 p-3">
                        {editingId === album._id ? (
                            <div className="flex items-center gap-2">
                                <input
                                    className={`${input} w-64`}
                                    value={editName}
                                    onChange={(e) => setEditName(e.target.value)}
                                />
                                <button className={btn} onClick={() => saveAlbum(album._id)}>Save</button>
                                <button className={btnGray} onClick={() => setEditingId(null)}>Cancel</button>
                            </div>
                        ) : (
                            <div className="flex items-center justify-between gap-2">
                                <h3 className="text-lg font-medium">{album.name}</h3>
                                <div className="flex gap-2">
                                    <button className={btn} onClick={() => openAlbum(album._id)}>View</button>
                                    {isMe && <button className={btnGray} onClick={() => startEdit(album)}>Edit</button>}
                                    {isMe && <button className={btnRed} onClick={() => deleteAlbum(album._id)}>Delete</button>}
                                </div>
                            </div>
                        )}
                    </div>
                ))}
            </div>

            {selected && (
                <div className="space-y-6 border-t border-gray-200 pt-6">
                    <div className="space-y-3">
                        <h3 className="text-lg font-semibold">Posts in {selected.name}</h3>
                        {selected.posts.length === 0 && <p className="text-gray-500">No posts saved yet</p>}
                        <div className="grid grid-cols-3 gap-4">
                            {selected.posts.map((post) => (
                                <div key={post._id} className="flex min-w-0 flex-col gap-2">
                                    <PostPreview post={post} />
                                    {isMe && (
                                        <button className={btnRed} onClick={() => removePost(post._id)}>
                                            Remove from album
                                        </button>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>

                    {isMe && (
                        <div className="space-y-3">
                            <h3 className="text-lg font-semibold">Add posts to {selected.name}</h3>
                            {addable.length === 0 && (
                                <p className="text-gray-500">All your posts are already in this album</p>
                            )}
                            <div className="grid grid-cols-3 gap-4">
                                {addable.map((post) => (
                                    <div key={post._id} className="flex min-w-0 flex-col gap-2">
                                        <Image
                                            src={post.image}
                                            alt={post.caption}
                                            className="aspect-square w-full rounded-lg object-cover"
                                        />
                                        <p className="truncate text-sm">{post.caption}</p>
                                        <button className={btn} onClick={() => addPost(post._id)}>
                                            Add to album
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

export default Album;